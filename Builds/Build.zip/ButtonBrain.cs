﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtonBrain : MonoBehaviour
{
    // Start is called before the first frame update

    public string val = "";
    public int priority = -1;

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
